<?php
session_start();
include_once '../connec7.php';	
$message="";
if(!empty($_POST["login"])) {
	$password0 = $_POST["password"];
	 $password = md5($password0);
	$result = mysqli_query($conn2,"SELECT * FROM users WHERE shopid='". $_POST["shopid"]."' and password = '$password' and username = '". $_POST["user_name"]."' ");
	$row  = mysqli_fetch_array($result);
	if(is_array($row)) {
	$_SESSION["id"] = $row['id'];
	} else {
	$message = "Invalid Username or Password!";
    echo "<div style='padding:5px;background-color:red;color:#fff'>$message......</div>";    
	}
}
if(!empty($_POST["logout"])) {
	$_SESSION["id"] = "";
	session_destroy();
} 
 
 date_default_timezone_set('GMT');
$date = date("Y-m-d"); 
$today = date("Y/m/d"); 
$lseen = date("Y/m/d"); 
$year = date("Y");
$tid = date("m/Y"); 
 
$a = date('h');
$b = date('i');
$time = "$a : $b";
$newpassword = "$a$b";
?>

<!DOCTYPE html>
<html>
<head>
<title>Login to your Shop</title>
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="../css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="../js/jquery.min.js"></script>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
<style>
#boxx{
	padding: 8px 12px;
		border: 2px solid #000;
		font-size: 1.1em;
		margin-bottom: 1.2em;
		font-weight: 400;
}
</style>

 <style>
      /* Popup Box */
      /* The Modal (background) */
      .modal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 8888; /* Sit on top */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
      }
      /* Modal Content/Box */
      .modal-content {
      background-color: #fefefe;
      margin: 10vh auto; /* 15% from the top and centered */
      padding: 20px;
      border: 1px solid #888;
      width: 80%; /* Could be more or less, depending on screen size */
      }
      @media (min-width: 1366px) {
      .modal-content {
      background-color: #fefefe;
      margin: 10vh auto; /* 15% from the top and centered */
      padding: 20px;
      border: 1px solid #888;
      width: 30%; /* Could be more or less, depending on screen size */
      }
      }
      h2, p {
      margin: 0 0 20px;
      font-weight: 400;
      color: #666;
      }
      span{
      color: #666;
      display:block;
      padding:0 0 5px;
      }
      form {
      padding: 25px;
      margin: 25px;
      box-shadow: 0 2px 5px #f5f5f5; 
      background: #eee; 
      }
      input, textarea {
      width: calc(100% - 18px);
      padding: 8px;
      margin-bottom: 20px;
      border: 1px solid #1c87c9;
      outline: none;
      }
      .contact-form button {
      width: 100%;
      padding: 10px;
      border: none;
      background: #1c87c9; 
      font-size: 16px;
      font-weight: 400;
      color: #fff;
      }
      button:hover {
      background: #2371a0;
      }    
      /* The Close Button */
      .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      }
      .close:hover,
      .close:focus {
      color: black;
      text-decoration: none;
      cursor: pointer;
      }
      button.button {
      background:none;
      border-top:none;
      outline: none;
      border-right:none;
      border-left:none;
      border-bottom:#02274a 1px solid;
      padding:0 0 3px 0;
      font-size:16px;
      cursor:pointer;
      }
      button.button:hover {
      border-bottom:#a99567 1px solid;
      color:#a99567;
      }
    </style>
</head>
<body>
	<!-- header-section-starts -->
	<div class="xxxfull">
			 
		<div class="xxxmain">
		<div class="contact-content">
			<div class="top-header span_top">
				<div class="logo">
					 
					<p>Welcome back to SimplePos</p>
				</div>
				 
				<div class="clearfix"></div>
			</div>
			<!---contact-->
<div class="main-contact" align="center">
		 <h3 class="head">LOGIN TO YOUR SHOP</h3>
		  
		 <div class="contact-form">
		 <?php if(empty($_SESSION["id"])) { ?>
			 <form method="post" action="" id="frmLogin">
				 <div classxxx="col-md-6 contact-left">
					  <input type="text" maxlength="10" id="boxx" style="width:200px" name="shopid" placeholder="Shop ID" required/>
					 <br>
<input type="text" maxlength="10" id="boxx" style="width:200px" name="user_name" placeholder="Username" required/>
					 					 <br> <input type="password" maxlength="10" style="width:200px" id="boxx" name="password" placeholder="Password" required/>
					  <br>
					    <input type="submit" name="login" style="width:200px" value="LOGIN"/>
				  </div>
				   <button class="button" data-modal="password">Manage Password</button>
   
				 <div class="clearfix"></div>
			 </form>
			 <?php 
} else { echo "<script>window.location='../'</script>";} ?>
	     </div>
		 <?php
		 
if(isset($_POST['submit'])){ 		 
	$email =  $_POST['email'];	
	
	$sql = "SELECT * FROM shops WHERE email = '$email'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $emaildb=$row["email"]; $shopiddb=$row["shopid"];

 
	
$to = $emaildb;
$subject = "Your New Password - SimplePos";
$message = "Your Shop ID is $shopiddb \n\n Your new password is $newpassword";
$headers = "From: sbstechghana@gmail.com\r\n" .
           "Reply-To: sbstechghana@gmail.com\r\n" .
           "X-Mailer: PHP/" . phpversion();

if (mail($to, $subject, $message, $headers)) {
  echo "<h2 style='color:green'>Your new password is sent to $emaildb</h2>";
} else {
  echo "Failed to change password. Try again...";
}

}}else{echo "<h2>We don't recorgnize this email address";}

}
?>
		<!-- <div class="contact_info">
			 <h3>Find Us Here</h3>
			 <div class="map">
				<iframe width="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265" style="color:#000;text-align:left;font-size:12px">View Larger Map</a></small>
			</div>
	 </div>-->
</div>
	 <div class="footer">
		<h6>Disclaimer : </h6>
		<p class="claim">SimplePos. All right reserved.  </p>
		 
	</div> 
	</div>
	<div class="clearfix"></div>
	</div>
	
 <div id="password" class="modal">
      <div class="modal-content">
        <div class="contact-form">
          <a class="close">&times;</a>
          <form action="./" method="POST">
            <p>Hi, we shall change your password and send to your email address.<br>Enter your email address below:</p>
            <div>
              <input class="fname" type="text" name="email" placeholder="Enter your email address here">
                 </div>
             <button type="submit" name="submit">Submit</button>
          </form>
        </div>
      </div>
    </div>						 
						 
<?php	
	if(isset($_POST['register'])){ 		 
	$shopname =  $_POST['shopname'];
		$contacts =  $_POST['contacts'];        
		$location = $_POST['location'];
		$password = $_POST['password'];
 
$sql = "SELECT id FROM shops ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $lastid=$row["id"] + 1; }} $username = "SP$lastid";

$sql = "INSERT INTO shops(shopname, contacts, location, password, username)VALUES 
('$shopname', '$contacts','$location', '$password','$username')"; if ($conn->query($sql) === TRUE) { echo "
SHOP IS REGISTERED. YOUR ID IS $username and your password is $password"; } else { echo "Error saving record: " . $conn->error; }	


	}
	
	
	
?>

<script>
      var modalBtns = [...document.querySelectorAll(".button")];
      modalBtns.forEach(function(btn){
        btn.onclick = function() {
          var modal = btn.getAttribute('data-modal');
          document.getElementById(modal).style.display = "block";
        }
      });
      
      var closeBtns = [...document.querySelectorAll(".close")];
      closeBtns.forEach(function(btn){
        btn.onclick = function() {
          var modal = btn.closest('.modal');
          modal.style.display = "none";
        }
      });
      
      window.onclick = function(event) {
        if (event.target.className === "modal") {
          event.target.style.display = "none";
        }
      }
    </script>
</body>
</html>
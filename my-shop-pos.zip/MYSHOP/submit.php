<style>
#cart{padding:5px}
</style>
<?php
session_start();
include_once 'connec7.php'; 
if(empty($_SESSION["id"])) {  
echo "<script>window.location='login/'</script>";
} else { 
$result = mysqlI_query($conn2,"SELECT * FROM shops WHERE id='" . $_SESSION["id"] . "'");
$row  = mysqli_fetch_array($result);
     $shopid= ($row['username']);
   $contacts = ($row['contacts']);
     $location = $row['location'];  
  
 } 

date_default_timezone_set('GMT');
$date = date("Y/m/d"); 
$lseen = date("Y/m/d"); 
$year = date("Y");
$tid = date("m/Y"); 
 
$a = date('h');
$b = date('i:s');
$time = "$a : $b";
 
 
 
//	 $productname = htmlentities($_POST['name']);
//$productname = addslashes($productname);
//$quantity = $_POST['email']; 

 
//if(strlen($productname)<1){echo "<font color='red'><h4 style=''>"; $output = json_encode(array(''=>'ERROR: ', '' => 'No product selected!! Select a product, Add, then Sell')); die($output); }
//if(strlen($quantity)<1){echo "<font color='red'><h4 style=''>"; $output = json_encode(array(''=>'ERROR: ', '' => 'No quantity entered!! Enter quantity, Add, then Sell')); die($output); }
 
/**	
 $sql = "SELECT * FROM products WHERE productname = '$productname' LIMIT 1";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $sellprice=$row["sellprice"] ; $costprice=$row["costprice"] ;  }}

		       
		$total = $sellprice * $quantity;
$sql = "INSERT INTO selling(status,total, tid,date,times, productname, quantity, costprice, sellprice, shopid )VALUES 
('cart','$total', '$tid','$date','$time','$productname', '$quantity','$costprice', '$sellprice','$shopid' )"; 
if ($conn->query($sql) === TRUE) { echo ""; } else { echo "Error saving record: " . $conn->error; }	

echo "<table border='0'>";
 $sql = "SELECT * FROM selling WHERE status = 'cart' AND shopid='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $id=$row["id"] ;$quantity=$row["quantity"] ; $productname=$row["productname"] ;$sellprice=$row["sellprice"] ; 
$costprice=$row["costprice"] ; $total = $sellprice * $quantity;
echo "
<form method='post' action='submit.php'>
<input type='text' value='$id' name='idd'>
<tr><td id='cart'>$productname</td><td id='cart'>$quantity</td><td id='cart'>$total</td><td id='cart'><input type='submit' name='remove' value='x' title='remove' style='color:red;border-style:none;padding:4px;border-radius:3px;cursor:pointer;'></td></tr>
</form>";
}}
$sql = "SELECT SUM(total) FROM selling WHERE status = 'cart' AND shopid='$shopid'"; $result = $conn->query($sql); if ($result->num_rows>0){ while($row = $result->fetch_assoc()) { $total = $row["SUM(total)"];   } }  

echo "<tr><td colspan='2' id='cart'>Total</td><td id='cart'>$total</td></tr>";
echo "</table>";
**/
//}else{echo "No quantity entered!! Enter quantity, Add, then Sell";}
//}else{echo "No product selected!! Select a product, Add, then Sell";}
  //echo $_POST['productname'] . "<br />";
  //echo $_POST['quantity'] . "<br />";
// echo $_POST['name'] . "<br />";
  //echo $_POST['email'] . "<br />";
 // echo "==============================<br />";
 // echo "All Data Submitted Successfully!";
 
 //if(isset($_POST['remove'])){ 		 
	$idd =  $_POST['name'];
	
	$sql = "DELETE FROM selling WHERE id='$idd'";if ($conn->query($sql) === TRUE) { 
	
	echo "gone $idd";} else {   echo "Error deleting record: " . $conn->error; }

 //}
?>

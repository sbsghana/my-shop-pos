<?php
session_start();
include_once 'connec7.php'; 
if(empty($_SESSION["id"])) {  
echo "<script>window.location='login/'</script>";
} else { 
$result = mysqlI_query($conn2,"SELECT * FROM users WHERE id='" . $_SESSION["id"] . "'");
$row  = mysqli_fetch_array($result);
  $shopid = $row['shopid'];  
      $fullname = $row['fullname'];
 } 
 //find your shopid
  $sql = "SELECT * FROM shops WHERE id='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $email=$row["email"]; $shopname=$row["shopname"]; $contacts=$row["contacts"] ; $location=$row["location"]; 
}}

date_default_timezone_set('GMT');
$date = date("Y-m-d"); 
$lseen = date("Y/m/d"); 
$year = date("Y");
$tid = date("m/Y"); 
 
$a = date('h');
$b = date('i:s');
$time = "$a : $b";
$fulldate = date("l jS \of F Y") ;
$monthdate = date("F Y");
?>
<!DOCTYPE html>
<html>
<head>
<title>add</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
<style>
#boxx{
	padding: 8px 12px;
		border: 2px solid #000;
		font-size: 1.1em;
		margin-bottom: 1.2em;
		font-weight: 400;
}
 
#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 70%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}
</style>
</head>
<body>
	<!-- header-section-starts -->
	<div class="xxxfull">
			 <div class="xxxmain">
		<div class="xxxcontact-content">
			 <!---contact-->
<div class="main-contact">
		  <div class="xxxcontact-form">
			 <form method="post" action="reports111222555.php">
				  <div  >
					  <input type="submit" style="width:200px" name="today" value="TODAY SALES"/>
				 
					  <input type="submit" style="width:200px" name="thismonth" value="THIS MONTH"/>
				 
					  <input type="submit" style="width:200px" name="all" value="ALL SALES"/>
				 <input type="submit" style="width:200px" name="expenses" value="EXPENSES"/>
				
				</div>
				 <div class="clearfix"></div>
			 </form>
	     </div>

<br><br>
<table id="customers">	
<?php	
	if(isset($_POST['today'])){ 
echo "<tr><th>TODAY</th><th>PRODUCT</th><th>QTY</th><th>PRICE</th></tr>";	
	 
 $sql = "SELECT * FROM selling WHERE status='sold' AND date = '$date' AND shopid='$shopid' ORDER BY id DESC";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $date=$row["date"] ; $time=$row["times"] ; $productname=$row["productname"] ; $quantity=$row["quantity"] ;
$sellprice=$row["sellprice"] ; $price = $sellprice * $quantity;   
echo "<tr><td>$date - $time</td><td>$productname</td><td>$quantity</td><td>$price</td></tr>";
 }}
 
 $sql = "SELECT SUM(total) FROM selling WHERE date = '$date' AND status='sold' AND shopid='$shopid'"; $result = $conn->query($sql); if ($result->num_rows>0){ while($row = $result->fetch_assoc()) { $total = $row["SUM(total)"];   } }  

 echo "<tr><td colspan='3'>TOTAL</td><td>$total</td></tr>"; 
	
	}
	
	
	
	if(isset($_POST['expenses'])){ 
echo "<tr><th>DATE</th><th>EXPENSES</th><th>AMOUNT</th><th>INPUTER</th></tr>";	
	 
 $sql = "SELECT * FROM expenses WHERE shopid='$shopid' ORDER BY id DESC";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $date=$row["date"] ; $expenses=$row["expenses"] ; $amount=$row["amount"] ; 
$inputer=$row["inputer"] ;
 echo "<tr><td>$date  </td><td>$expenses</td><td>$amount</td><td>$inputer</td></tr>";
 }}
 
 //$sql = "SELECT SUM(total) FROM selling WHERE date = '$date' AND status='sold' AND shopid='$shopid'"; $result = $conn->query($sql); if ($result->num_rows>0){ while($row = $result->fetch_assoc()) { $total = $row["SUM(total)"];   } }  

 //echo "<tr><td colspan='3'>TOTAL</td><td>$total</td></tr>"; 
	
	}

?>
</table>

<table id="customers">	
<?php	
	if(isset($_POST['thismonth'])){ 
echo "<tr><th>THIS MONTH</th><th>PRODUCT</th><th>QTY</th><th>PRICE</th></tr>";	
	 
 $sql = "SELECT * FROM selling WHERE status='sold' AND tid = '$tid' AND shopid='$shopid' ORDER BY id DESC";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $date=$row["date"] ; $time=$row["times"] ; $productname=$row["productname"] ; $quantity=$row["quantity"] ;
$sellprice=$row["sellprice"] ; $price = $sellprice * $quantity;   
echo "<tr><td>$date - $time</td><td>$productname</td><td>$quantity</td><td>$price</td></tr>";
 }}
 
 $sql = "SELECT SUM(total) FROM selling WHERE tid = '$tid' AND status='sold' AND shopid='$shopid'"; $result = $conn->query($sql); if ($result->num_rows>0){ while($row = $result->fetch_assoc()) { $total = $row["SUM(total)"];   } }  

 echo "<tr><td colspan='3'>TOTAL</td><td>$total</td></tr>"; 
	
	}

?>
</table>

<table id="customers">	
<?php	
	if(isset($_POST['all'])){ 
echo "<tr><th>ALL</th><th>PRODUCT</th><th>QTY</th><th>PRICE</th></tr>";	
	 
 $sql = "SELECT * FROM selling WHERE status='sold' AND shopid='$shopid' ORDER BY id DESC";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $date=$row["date"] ; $time=$row["times"] ; $productname=$row["productname"] ; $quantity=$row["quantity"] ;
$sellprice=$row["sellprice"] ; $price = $sellprice * $quantity;   
echo "<tr><td>$date - $time</td><td>$productname</td><td>$quantity</td><td>$price</td></tr>";
 }}
 
 $sql = "SELECT SUM(total) FROM selling WHERE shopid='$shopid' AND status='sold'"; $result = $conn->query($sql); if ($result->num_rows>0){ while($row = $result->fetch_assoc()) { $total = $row["SUM(total)"];   } }  

 echo "<tr><td colspan='3'>TOTAL</td><td>$total</td></tr>"; 
	
	}

?>
</table>
</div>
	<form method="POST" action="reports111222555.php">
	<input type="submit" name="sendtoday" value="Send today profit to my mail">
	<input type="submit" name="sendmonth" value="Send this month profit to my mail">
	</form>
	
	 <?php
		 
if(isset($_POST['sendtoday'])){ 		 

$sql = "SELECT * FROM selling WHERE status='sold' AND date = '$date' AND shopid='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $sellprice=$row["sellprice"] ; $costprice=$row["costprice"] ; 
$profit = $sellprice - $costprice; $totalprofit = $totalprofit + $profit; 
 }}
 
$to = $myemail;
$subject = "Your Day Profit - SimplePos";
$message = "Your Profit as at $fulldate is $totalprofit";
$headers = "From: sbstechghana@gmail.com\r\n" .
           "Reply-To: sbstechghana@gmail.com\r\n" .
           "X-Mailer: PHP/" . phpversion();

if (mail($to, $subject, $message, $headers)) {
  echo "<h2 style='color:green'>Your profit is sent to $myemail</h2>";
} else {
  echo "Failed  . Try again...";
}

 
}




if(isset($_POST['sendmonth'])){ 	

$sql = "SELECT * FROM selling WHERE status='sold' AND tid = '$tid' AND shopid='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $sellprice=$row["sellprice"] ; $costprice=$row["costprice"] ; 
$profit = $sellprice - $costprice; $totalprofit = $totalprofit + $profit; 
 }}	 
	
$to = $myemail;
$subject = "Your Month Profit - SimplePos";
$message = "Your Profit as at $monthdate is $totalprofit";
$headers = "From: sbstechghana@gmail.com\r\n" .
           "Reply-To: sbstechghana@gmail.com\r\n" .
           "X-Mailer: PHP/" . phpversion();

if (mail($to, $subject, $message, $headers)) {
  echo "<h2 style='color:green'>Your profit is sent to $myemail</h2>";
} else {
  echo "Failed  . Try again...";
}

 
}
?>
	</div>
	<div class="clearfix"></div>
	</div>
	
	 
</body>
</html>
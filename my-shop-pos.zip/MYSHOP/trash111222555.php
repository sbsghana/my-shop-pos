<?php
session_start();
include_once 'connec7.php'; 
if(empty($_SESSION["id"])) {  
echo "<script>window.location='login/'</script>";
} else { 
$result = mysqlI_query($conn2,"SELECT * FROM shops WHERE id='" . $_SESSION["id"] . "'");
$row  = mysqli_fetch_array($result);
  $shopid = $row['id'];  
    $shopid= ($row['username']);
   $contacts = ($row['contacts']);
     $location = $row['location'];  
  
 } 

date_default_timezone_set('GMT');
$date = date("Y/m/d"); 
$lseen = date("Y/m/d"); 
$year = date("Y");
$tid = date("m/Y"); 
 
$a = date('h');
$b = date('i:s');
$time = "$a : $b";
 
?>
<!DOCTYPE html>
<html>
<head>
<title>Stock</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
<style>
#boxx{
	padding: 8px 12px;
		border: 2px solid #000;
		font-size: 1.1em;
		margin-bottom: 1.2em;
		font-weight: 400;
}
 
#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 70%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}
</style>
</head>
<body>
	<!-- header-section-starts -->
	<div class="xxxfull">
			 <div class="xxxmain">
		<div class="xxxcontact-content">
			 <!---contact-->
<div class="main-contact">
		 

<br><br>
<table id="customers">	
<?php		 
echo "<tr><th>DATE</th><th>DETAILS</th></tr>";		 
$sql = "SELECT * FROM trash WHERE shopid='$shopid' ORDER BY id DESC";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $date=$row["date"] ; $descr=$row["descr"] ;
echo "<tr><td>$date</td><td>$descr</td></tr>";
 }}	 
?>
</table>
 
</div>
	 </div>
	<div class="clearfix"></div>
	</div>
	
	 
</body>
</html>
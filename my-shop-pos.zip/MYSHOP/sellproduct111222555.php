<?php
session_start();
include_once 'connec7.php'; 
if(empty($_SESSION["id"])) {  
echo "<script>window.location='login/'</script>";
} else { 
$result = mysqlI_query($conn2,"SELECT * FROM users WHERE id='" . $_SESSION["id"] . "'");
$row  = mysqli_fetch_array($result);
  $shopid = $row['shopid'];  
      $fullname = $row['fullname'];
	   $customerindb = $row['customer'];
	   $username = $row['username'];
 } 
 //find your shopid
  $sql = "SELECT * FROM shops WHERE id='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $email=$row["email"]; $shopname=$row["shopname"]; $contacts=$row["contacts"] ; $location=$row["location"]; 
}}

date_default_timezone_set('GMT');
$date = date("Y-m-d"); 
$lseen = date("Y/m/d"); 
$year = date("Y");
$tid = date("m/Y"); 
 
$a = date('h');
$b = date('i:s');
$time = "$a : $b";
 
?>
<!DOCTYPE html>
<html>
<head>
<title>add</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
<style>
#boxx{
	padding: 8px 12px;
		border: 2px solid #000;
		font-size: 1.1em;
		margin-bottom: 1.2em;
		font-weight: 400;
}


#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 70%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}

#cart{padding:5px}
</style>
<script src="js/jquery-latest.js"></script>
<script src="js/submit.js"></script>
</head>
<body>
	<!-- header-section-starts -->
	<div class="xxxfull">
			 <div class="xxxmain">
		<div class="contact-content">
			 <!---contact-->
<div class="main-contact">
		  <h3 class="head">Select a product, Add, then Sell</h3> 
		  
		  
		  
		 <div class="contact-form">
			 
				 <div class="col-md-6 contact-left">
				  <form method="post"   action="sellproduct111222555.php">
			
				 <table>
				 <!--<tr><td colspan="3">Customer
				 <select name="customer" class="form-control">
				 <option><?php echo $customerindb;?></option>
				 <option>Walk-in Customer</option>
				 <?php
			//	 $sql = "SELECT * FROM customers WHERE shopid='$shopid' ORDER BY name ASC";
//$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
//{ $cid=$row["id"];$productbalance=$row["productbalance"]; $name=$row["name"]; $phone=$row["phone"] ; $email=$row["email"]; $address=$row["address"] ;  
//$full = "$email $address"; 
//if($productbalance > 0){$do="disabled"; $say="owing";}else{$do=""; $say="";}
//echo "<option title='$full' value='$cid' $do>$name $phone $say</option>";
//}}
?>
				 </select>-->
				 </td>
				 <tr>
				 
				 <td>
				 <select required name="productname" class="form-control">
				 <option></option>
				 <?php
				 $sql = "SELECT * FROM products WHERE quantity > 0 AND shopid = '$shopid' ORDER BY productname";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $productname=$row["productname"]; $sellp=$row["sellprice"] ; $quan=$row["quantity"] ; 
$full = "Price: GHS$sellp \n Qty: $quan"; 
echo "<option title='$full'>$productname</option>";
}}
?>
				 </select>
 	</td>
				<td><br>
	 <input type="number" name="quantity" style="width:150px" class="form-control" placeholder="Quantity" required/>
	 </td>
	 <td>
	 
			 <button type="submit" name="add" class="form-control" stylev="padding:5px;background-color:#fff">Add</button>
	</td>
	</tr>
	</table>
	 </form>
<br>

<?php
if(isset($_POST['add'])){ 	
//echo "<script>window.location='sellproduct111222555.php';</script>";	 
	 $productname = htmlentities($_POST['productname']);
$productname = addslashes($productname);
$quantity = $_POST['quantity'];
        		
$sql = "SELECT * FROM products WHERE productname = '$productname' LIMIT 1";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $sellprice=$row["sellprice"] ; $costprice=$row["costprice"] ;  }}
$total = $sellprice * $quantity;
		
$sql = "INSERT INTO selling( type,inputer,customer,status,total, tid,date,times, productname, quantity, costprice, sellprice, shopid )VALUES 
( 'New bought','$fullname','$customerindb','cart','$total', '$tid','$date','$time','$productname', '$quantity','$costprice', '$sellprice','$shopid' )"; 
if ($conn->query($sql) === TRUE) { echo ""; } else { echo "Error saving record: " . $conn->error; }	

echo "<table border='0'>";
 $sql = "SELECT * FROM selling WHERE status = 'cart' AND shopid='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $id=$row["id"] ;$quantity=$row["quantity"] ; $productname=$row["productname"] ;$sellprice=$row["sellprice"] ; 
$costprice=$row["costprice"] ; $total = $sellprice * $quantity;
echo "
<form method='post' id='myForm' action='sellproduct111222555.php'>
<input type='text' value='$id' name='name' id='name' style='visibility:hidden;position:absolute'>
<tr><td id='cart'>$productname</td><td id='cart'>$quantity</td><td id='cart'>$total</td>
<td id='cart'><input type='submit' value='x' name='remove' title='remove' id='submitFormData' onclick='SubmitFormData();' style='background-color:#fff;color:red;border-style:none;padding:4px;border-radius:3px;cursor:pointer;'></td><td><div id='results'></div></td></tr>
</form>
";
}}
$sql = "SELECT SUM(total) FROM selling WHERE status = 'cart' AND shopid='$shopid'"; $result = $conn->query($sql); if ($result->num_rows>0){ while($row = $result->fetch_assoc()) { $total = $row["SUM(total)"];   } }  

echo "<tr><td colspan='2' id='cart'><b>Total</b></td><td id='cart'><b>$total</b></td></tr>";
//echo "<tr><td><br>Amount Paying GHS <input type='text' name='amountpaying'></td></tr>";
echo "</table>";
?>
<br>
<form method="POST" action="print/">

<?php echo "Amount Paying GHS <input type='text' required name='amountpaid'>
Customer  <br>
 <select required name='cid' style='padding:5px;background-color:#fff;border-style:solid'>
 <option></option>"; 
$sql = "SELECT * FROM customers WHERE shopid='$shopid' ORDER BY name ASC";
 $result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
 { $cid=$row["id"];$productbalance=$row["productbalance"]; $name=$row["name"]; $phone=$row["phone"] ; $email=$row["email"]; $address=$row["address"] ;  
 $full = "$email $address"; 
 if($productbalance > 0){$do="disabled"; $say="owing";}else{$do=""; $say="";}
 echo "<option title='$full' value='$cid' $do>$name $phone $say</option>";
 }}
?>
</select><br>
<br>
 <input type="submit" name="sell" value="SELL"/>
</form>
<?php
}

////////////////////////////////////////////////

if(isset($_POST['remove'])){ 		 
	$idd =  $_POST['name'];
	
	$sql = "DELETE FROM selling WHERE id='$idd'";if ($conn->query($sql) === TRUE) { } else {   echo "Error deleting record: " . $conn->error; }

echo "<form method='post' id='myForm' action='sellproduct111222555.php'>
<table border='0'>";
 $sql = "SELECT * FROM selling WHERE status = 'cart' AND shopid='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $id=$row["id"] ;$quantity=$row["quantity"] ; $productname=$row["productname"] ;$sellprice=$row["sellprice"] ; 
$costprice=$row["costprice"] ; $total = $sellprice * $quantity;
echo "
<form method='post' id='myForm' action='sellproduct111222555.php'>
<input type='text' value='$id' name='name' id='name' style='visibility:hidden;position:absolute'>
<tr><td id='cart'>$productname</td><td id='cart'>$quantity</td><td id='cart'>$total</td>
<td id='cart'><input type='submit' value='x' name='remove' title='remove' id='submitFormData' onclick='SubmitFormData();' style='background-color:#fff;color:red;border-style:none;padding:4px;border-radius:3px;cursor:pointer;'></td><td><div id='results'></div></td></tr>
</form>
";
}}
$sql = "SELECT SUM(total) FROM selling WHERE status = 'cart' AND shopid='$shopid'"; $result = $conn->query($sql); if ($result->num_rows>0){ while($row = $result->fetch_assoc()) { $total = $row["SUM(total)"];   } }  

echo "<tr><td colspan='2' id='cart'>Total</td><td id='cart'>$total</td></tr>";
echo "</table></form>";
?>
<br>
 
<form method="POST" action="print/">
<?php echo "Amount Paying GHS <input type='text' required name='amountpaid'>
Customer  <br>
 <select required name='cid' style='padding:5px;background-color:#fff;border-style:solid'>
 <option></option>"; 
$sql = "SELECT * FROM customers WHERE shopid='$shopid' ORDER BY name ASC";
 $result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
 { $cid=$row["id"];$productbalance=$row["productbalance"]; $name=$row["name"]; $phone=$row["phone"] ; $email=$row["email"]; $address=$row["address"] ;  
 $full = "$email $address"; 
 if($productbalance > 0){$do="disabled"; $say="owing";}else{$do=""; $say="";}
 echo "<option title='$full' value='$cid' $do>$name $phone $say</option>";
 }}
?>
</select><br>
<br>
 <input type="submit" name="sell" value="SELL"/>
</form>
  
<?php
 }

?>

				  </div>
				  
				  
				 <div class="clearfix"></div>
			
	     </div>
		 <!-- <div class="contact_info">
		 		
			 <h3>Find Us Here</h3>
			 <div class="map">
				<iframe width="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265" style="color:#000;text-align:left;font-size:12px">View Larger Map</a></small>
			</div>
	 </div> -->
</div>
	<!--<div class="footer">
		<h6>Disclaimer : </h6>
		<p class="claim">This is a freebies and not an official website, I have no intention of disclose any movie, brand, news.My goal here is to train or excercise my skill and share this freebies.</p>
		<a href="example@mail.com">example@mail.com</a>
		<div class="copyright">
			<p> Template by  <a href="http://w3layouts.com">  W3layouts</a></p>
		</div>
	</div>	-->
	</div>
	<div class="clearfix"></div>
	</div>
<!--	
<form method='post' action='sellproduct111222555.php'><input type='submit' value='Go to Print' name='gotoprint'></form>						 
	-->					 
<?php	
	if(isset($_POST['sell'])){ 		 
	 $productname = htmlentities($_POST['productname']);
$productname = addslashes($productname);

 $sql = "SELECT * FROM products WHERE productname = '$productname' LIMIT 1";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $sellprice=$row["sellprice"] ; $costprice=$row["costprice"] ;  }}

		$quantity = $_POST['quantity'];        
		$total = $sellprice * $quantity;
		$customer = $_POST['customer'];     
$sql = "INSERT INTO selling(customer,status,total, tid,date,times, productname, quantity, costprice, sellprice, shopid )VALUES 
('$customer','sold','$total', '$tid','$date','$time','$productname', '$quantity','$costprice', '$sellprice','$shopid' )"; if ($conn->query($sql) === TRUE) { echo "
<h4 style='padding:10px;color:#fff;background-color:green;width:100%'>$quantity quantity of $productname sold for GHS$total <form method='post' action='sellproduct111222555.php'><input type='submit' value='Go to Print' name='gotoprint'></form>"; } else { echo "Error saving record: " . $conn->error; }	

$sql = "UPDATE products SET quantity=quantity - '$quantity'"; if ($conn->query($sql) === TRUE) { echo "";}
 
	}

if(isset($_POST['gotoprint'])){ 	
echo "
<div style='width:100%;background-color:#fff;padding:20px;position:absolute;top:0px;'>
<form method='post' action='print/'>
<h4>Select what to print</h4><br>";
echo "<div style='height:300px;width:100%;background-color:#fff;over-flow:scroll'>";
echo "<table id='customers'>";	
	 
echo "<tr><th></th><th>PRODUCT</th><th>QTY</th><th>PRICE</th></tr>";	
	 
 $sql = "SELECT * FROM selling WHERE status='sold' AND tid = '$tid' AND shopid='$shopid' ORDER BY id DESC";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $id=$row["id"] ;$date=$row["date"] ; $time=$row["times"] ; $productname=$row["productname"] ; $quantity=$row["quantity"] ;
$sellprice=$row["sellprice"] ; $price = $sellprice * $quantity;   
echo "<tr><td><input type='checkbox' name='select$id' value='$productname $quantity $price'></td><td>$productname ($date $time)</td><td>$quantity</td><td>$price</td></tr>";
 }}  

echo "</table>";
echo "</div>";
echo "<div align='center'><a href='sellproduct111222555.php?idd=4343295465-3465374-57-4574674565-4635634634-6346343'>CANCEL</a>";
echo "&nbsp;&nbsp;&nbsp;&nbsp;<input type='submit' value='PRINT' style='width:100px'></div>";
echo "</form>";
echo "</div>";
}

?>


</body>
</html>
<?php
 session_start();
include_once '../connec7.php'; 
if(empty($_SESSION["id"])) {  
echo "<script>window.location='login/'</script>";
} else { 
$result = mysqlI_query($conn2,"SELECT * FROM users WHERE id='" . $_SESSION["id"] . "'");
$row  = mysqli_fetch_array($result);
  $shopid = $row['shopid'];  
      $fullname = $row['fullname'];
 } 
 //find your shopid
  $sql = "SELECT * FROM shops WHERE id='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $email=$row["email"]; $shopname=$row["shopname"]; $contacts=$row["contacts"] ; $location=$row["location"]; 
}}

date_default_timezone_set('GMT');
$date = date("Y-m-d"); 
$lseen = date("Y/m/d"); 
$year = date("Y");
$tid = date("m/Y"); 
 
$a = date('h');
$b = date('i:s');
$time = "$a : $b";
 
?>
<?php
 $amountpaid = $_POST['amountpaid'];
  $cid = $_POST['cid'];
 $sql = "SELECT * FROM customers WHERE  id='$cid'  ";
 $result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
 {  $customer=$row["name"]; $productbalance=$row["productbalance"] ;}}
  $sql = "SELECT SUM(total) FROM selling WHERE status = 'cart' AND shopid='$shopid'"; $result = $conn->query($sql); if ($result->num_rows>0){ while($row = $result->fetch_assoc()) { $total = $row["SUM(total)"];   } }  

 if($amountpaid >  $total){ echo "<a href='../sellproduct111222555.php'><font color='#fff'><h4 style='position:absolute;top:20px;background-color:red;padding:20px;width:100%'>"; $output = json_encode(array(''=>'ERROR: ', '' => 'Amount paying is bigger than product cost')); die($output); }

   echo "<table border='1'>
       <tr><th colspan='3'><div>$shopname<br>$location - $contacts<br>Payment Receipt</div><br>Customer: $customer</th></tr>";
 echo "<tr><td>Product</td><td>Qty</td><td>Price</td></tr>";

 $sql = "SELECT * FROM selling WHERE status='cart' AND shopid='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $id=$row["id"] ;$date=$row["date"] ; $time=$row["times"] ; $productname=$row["productname"] ; $quantity=$row["quantity"] ;
$sellprice=$row["sellprice"] ; $price = $sellprice * $quantity;   
//echo "<tr><td><input type='checkbox' name='select$id' value='$productname $quantity $price'></td><td>$productname ($date $time)</td><td>$quantity</td><td>$price</td></tr>";
  
 echo "<tr><td>$productname</td><td>$quantity</td><td>$price</td></tr>";
 }} 
 $sql = "SELECT SUM(total) FROM selling WHERE status = 'cart' AND shopid='$shopid'"; $result = $conn->query($sql); if ($result->num_rows>0){ while($row = $result->fetch_assoc()) { $total = $row["SUM(total)"];   } }  
 $balance=$total-$amountpaid;
 echo "<tr><td colspan='2'><strong>Total</strong></td><td><strong>GHS$total</strng></td></tr>
 <tr><td colspan='2'><strong>Amount Paid</strong></td><td><strong>GHS$amountpaid</strng></td></tr>
 <tr><td colspan='2'><strong>Balance</strong></td><td><strong>GHS$balance</strng></td></tr>
 </table>";
 
 //if balance save to customer
 $sql = "UPDATE customers SET product='$productname', productbalance='$balance' WHERE id = '$cid' AND shopid='$shopid'"; if ($conn->query($sql) === TRUE) { echo "";}

 ////////////////////////////////////////
 
 

 

$sql = "SELECT * FROM selling WHERE status='cart' AND shopid='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $quantity=$row["quantity"] ;$id=$row["id"] ;$sellprice=$row["sellprice"] ; $costprice=$row["costprice"] ;  
$sql = "UPDATE products SET quantity=quantity - '$quantity' WHERE id = '$id' AND shopid='$shopid'"; if ($conn->query($sql) === TRUE) { echo "";}
 
$sql = "UPDATE selling SET amount='$amountpaid', status='sold', cid='$cid' WHERE id = '$id'"; if ($conn->query($sql) === TRUE) { echo "";}
}}
?>

<!DOCTYPE html>
<html>
<head>
<title>...</title>
 <script language="javascript" type="text/javascript">
function printer(){
window.print()
}
</script>
</head>
<body>
	 <form method="post" action="../sellproduct111222555.php">
	 <input type="submit" title="go back" value="<<" style="cursor:pointer;margin:40px;border-style:none;background-color:#fff">
	 </form>
	 <br>
	 <button onclick="javascript:printer();">Printout</button>
</body>
</html>
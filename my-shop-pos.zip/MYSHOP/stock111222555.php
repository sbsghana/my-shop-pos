<?php
session_start();
include_once 'connec7.php'; 
if(empty($_SESSION["id"])) {  
echo "<script>window.location='login/'</script>";
} else { 
$result = mysqlI_query($conn2,"SELECT * FROM users WHERE id='" . $_SESSION["id"] . "'");
$row  = mysqli_fetch_array($result);
  $shopid = $row['shopid'];  
      $fullname = $row['fullname'];
 } 
 //find your shopid
  $sql = "SELECT * FROM shops WHERE id='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $email=$row["email"]; $shopname=$row["shopname"]; $contacts=$row["contacts"] ; $location=$row["location"]; 
}}

date_default_timezone_set('GMT');
$date = date("Y/m/d"); 
$lseen = date("Y/m/d"); 
$year = date("Y");
$tid = date("m/Y"); 
$ttcp = 0; $ttsp = 0; 
$a = date('h');
$b = date('i:s');
$time = "$a : $b";
 
?>
<!DOCTYPE html>
<html>
<head>
<title>Stock</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
<style>
#boxx{
	padding: 8px 12px;
		border: 2px solid #000;
		font-size: 1.1em;
		margin-bottom: 1.2em;
		font-weight: 400;
}
 
#customers {
    font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
    border-collapse: collapse;
    width: 100%;
}

#customers td, #customers th {
    border: 1px solid #ddd;
    padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
    padding-top: 12px;
    padding-bottom: 12px;
    text-align: left;
    background-color: #4CAF50;
    color: white;
}

input{form-control}
</style>
</head>
<body>
	<!-- header-section-starts -->
	<div class="xxxfull">
			 <div class="xxxmain">
		<div class="xxxcontact-content">
			 <!---contact-->
<div class="main-contact">
		 

<br><br>
<table id="customers">	
<?php	
	 
echo "<tr><th>PRODUCT</th><th>QUANTITY</th><th>COST PRICE</th><th>SELL PRICE</th></tr>";	
	 
 $sql = "SELECT * FROM products WHERE shopid='$shopid' ORDER BY quantity ASC";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $productname=$row["productname"] ; $quantity=$row["quantity"] ;
$sellprice=$row["sellprice"] ;  $costprice=$row["costprice"] ;  $id=$row["id"] ;
$tcp=$quantity * $costprice; $ttcp = $ttcp + $tcp; 
$tsp=$quantity * $sellprice; $ttsp = $ttsp + $tsp;   
echo "<form method='post' action='stock111222555.php'>
<input style='visibility:hidden;position:absolute' value='$id' type='text' name='id'>
<tr><td>$productname</td><td>$quantity</td><td>$costprice</td><td>$sellprice</td><td><input type='submit' value='Manage' name='manage'></td>
 </tr></form>";
 }}
 
 $sql = "SELECT SUM(sellprice) FROM products WHERE shopid='$shopid'"; $result = $conn->query($sql); if ($result->num_rows>0){ while($row = $result->fetch_assoc()) { $total = $row["SUM(sellprice)"];   } }  
 
 echo "<tr><td colspan='3'>TOTAL</td><td>$total</td></tr>"; 
  echo "<tr><td colspan='3'>TOTAL COST PRICE (with quantity)</td><td>$ttcp</td></tr>"; 
   echo "<tr><td colspan='3'>TOTAL SELL PRICE (with quantity)</td><td>$ttsp</td></tr>"; 
	
	 
?>
</table>
 
<?php	
	if(isset($_POST['manage'])){ 
	$id =  $_POST['id'];       
	
	 $sql = "SELECT * FROM products WHERE id='$id'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $productname=$row["productname"] ; $quantity=$row["quantity"] ;
$sellprice=$row["sellprice"] ;  $costprice=$row["costprice"] ;  $id=$row["id"] ;    
}}
		
		 
	echo "<div style='width:100%;background-color:#fff;padding:20px;position:absolute;top:30px;z-index:22' align='center'>";
	echo "<form method='post' action='stock111222555.php'>
	<input style='visibility:hidden;position:absolute' value='$id' type='text' name='id'>
	<h3>MAKE NECCESSARY CHANGES</h3><br>
	<table width='80%'>
	<tr><td>Product Name<br><input value='$productname' type='text' name='productname' class='form-control'></td></tr>
	<tr><td>Quantity<br><input value='$quantity' type='number' name='quantity' class='form-control'><br></td></tr>
	<tr><td>Cost Price<br><input value='$costprice' type='text' name='costprice' class='form-control'></td></tr>
	<tr><td>Sell Price<br><input value='$sellprice' type='text' name='sellprice' class='form-control'></td></tr>
	
	</table>
	
	<input type='submit' name='save' value='SAVE CHANGES'><br><br>
	<input type='submit' name='delete' value='DELETE THIS PRODUCT' style='background-color:brown'><br><br>
	<a href='stock111222555.php'>cancel</a>
	</form>";
	echo "</div>";
	}
	
	
	
	if(isset($_POST['save'])){ 		 
	 $productname = htmlentities($_POST['productname']);
$productname = addslashes($productname);
		$quantity =  $_POST['quantity'];        
		$costprice = $_POST['costprice'];
		$sellprice = $_POST['sellprice'];
		$id = $_POST['id'];
		 	$element = "$costprice$sellprice";
		 
			if (is_numeric($element)){
 
//find original product
$sql = "SELECT * FROM products WHERE id='$id'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $productnamef=$row["productname"] ; $quantityf=$row["quantity"] ;
$sellpricef=$row["sellprice"] ;  $costpricef=$row["costprice"] ;  $id=$row["id"] ;    
}}
$sql = "UPDATE products SET productname='$productname',costprice='$costprice',sellprice='$sellprice', quantity='$quantity' WHERE id = '$id'"; if ($conn->query($sql) === TRUE) { echo "
<h4 style='position:absolute;top:0px; padding:10px;background-color:green;color:#fff;width:100%'>Changes saved</h4>";}


//add to trash
$descr = "The following changes was made. $productnamef changed to $productname. Quantity $quantityf changed to $quantity. Cost Price $costpricef changed to $costprice. Sell Price $sellpricef changed to $sellprice";
//$descr = "uuu";
$sql = "INSERT INTO trash(shopid,date,descr)VALUES ('$shopid','$date','$descr')"; if ($conn->query($sql) === TRUE) { echo "
"; } else { echo "Error saving record: " . $conn->error; }	

			}
	}
	
	
	
	if(isset($_POST['delete'])){ 		 	 
		$id = $_POST['id'];
		
		$sql = "SELECT * FROM products WHERE id='$id'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $productname=$row["productname"] ; $quantity=$row["quantity"] ;
$sellprice=$row["sellprice"] ;  $costprice=$row["costprice"] ;  $id=$row["id"] ;    
}}

$sql = "DELETE FROM products WHERE id='$id'";if ($conn->query($sql) === TRUE) { 
echo "<h3 style='position:absolute;top:0px; color:green'>$productname removed from stock</h3>";} else {   echo "Error deleting record: " . $conn->error; }
		 	 
//add to trash
$sql = "INSERT INTO trash(shopid,date,descr)VALUES 
('$shopid','$date','$productname removed from stock with the following details. Product name: $productname, Quantity: $quantity, Cost Price: $costprice, Sell Price: $sellprice')"; if ($conn->query($sql) === TRUE) { echo "
"; } else { echo "Error saving record: " . $conn->error; }	

		 
	}
	
	 
 

?>
</table>
</div>
	 </div>
	<div class="clearfix"></div>
	</div>
	
	 
</body>
</html>
<?php
session_start();
include_once 'connec7.php'; 
if(empty($_SESSION["id"])) {  
echo "<script>window.location='login/'</script>";
} else { 
$result = mysqlI_query($conn2,"SELECT * FROM users WHERE id='" . $_SESSION["id"] . "'");
$row  = mysqli_fetch_array($result);
  $shopid = $row['shopid'];  
      $fullname = $row['fullname'];
 } 
 //find your shopid
  $sql = "SELECT * FROM shops WHERE id='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $email=$row["email"]; $shopname=$row["shopname"]; $contacts=$row["contacts"] ; $location=$row["location"]; 
}}

date_default_timezone_set('GMT');
$date = date("Y-m-d"); 
$lseen = date("Y/m/d"); 
$year = date("Y");
$tid = date("m/Y"); 
 
$a = date('h');
$b = date('i:s');
$time = "$a : $b";
 
?>
<!DOCTYPE html>
<html>
<head>
<title>add</title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
<style>
#boxx{
	padding: 8px 12px;
		border: 2px solid #000;
		font-size: 1.1em;
		margin-bottom: 1.2em;
		font-weight: 400;
}
</style>
</head>
<body>
	<!-- header-section-starts -->
	<div class="full">
			 <div class="main">
		<div class="contact-content">
			 <!---contact-->
<div class="main-contact">
		<!-- <h3 class="head">ADD PRODUCT</h3>-->
		  
		 <div class="contact-form">
			 <form method="post" action="addexpenses75430703.php">
				 <div class="col-md-6 contact-left">
					  <input type="text" name="expenses" maxlength="50" placeholder="Expenses name" required/>
					  <input type="number" name="amount" maxlength="10" id="boxx" placeholder="Amount" required/>
					   
				 </div>
				  <div class="col-md-6 contact-right">
					 <!--<textarea placeholder="Message"></textarea>-->
					 <input type="submit" name="add" value="ADD"/>
				 </div>
				 <div class="clearfix"></div>
			 </form>
	     </div>
		<!-- <div class="contact_info">
			 <h3>Find Us Here</h3>
			 <div class="map">
				<iframe width="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265&amp;output=embed"></iframe><br><small><a href="https://maps.google.co.in/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Lighthouse+Point,+FL,+United+States&amp;aq=4&amp;oq=light&amp;sll=26.275636,-80.087265&amp;sspn=0.04941,0.104628&amp;ie=UTF8&amp;hq=&amp;hnear=Lighthouse+Point,+Broward,+Florida,+United+States&amp;t=m&amp;z=14&amp;ll=26.275636,-80.087265" style="color:#000;text-align:left;font-size:12px">View Larger Map</a></small>
			</div>
	 </div>-->
</div>
	<!--<div class="footer">
		<h6>Disclaimer : </h6>
		<p class="claim">This is a freebies and not an official website, I have no intention of disclose any movie, brand, news.My goal here is to train or excercise my skill and share this freebies.</p>
		<a href="example@mail.com">example@mail.com</a>
		<div class="copyright">
			<p> Template by  <a href="http://w3layouts.com">  W3layouts</a></p>
		</div>
	</div>	-->
	</div>
	<div class="clearfix"></div>
	</div>
	
						 
						 
<?php	
	if(isset($_POST['add'])){ 		 
	 $expenses =  $_POST['expenses'];        
		$amount = $_POST['amount'];
		 
$sql = "SELECT id FROM expenses ORDER BY id DESC LIMIT 1";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $invoice_no=$row["id"] + 1; }} 
	   
$sql = "INSERT INTO expenses(invoice_no,date,expenses,amount,shopid,inputer)VALUES 
('$invoice_no','$date','$expenses','$amount', '$shopid','$fullname')"; if ($conn->query($sql) === TRUE) { echo "
<h4 style='padding:10px;color:#fff;background-color:green;width:100%'>
New expenses added  </h4>"; } else { echo "Error saving record: " . $conn->error; }	
		} 

	 
?>
</body>
</html>
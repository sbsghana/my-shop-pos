<?php
session_start();
include_once 'connec7.php'; 
if(empty($_SESSION["id"])) {  
echo "<script>window.location='login/'</script>";
} else { 
$result = mysqlI_query($conn2,"SELECT * FROM users WHERE id='" . $_SESSION["id"] . "'");
$row  = mysqli_fetch_array($result);
  $shopid = $row['shopid'];  
      $fullname = $row['fullname'];
 } 
 //find your shopid
  $sql = "SELECT * FROM shops WHERE id='$shopid'";
$result = $conn->query($sql);if ($result->num_rows>0){ while($row = $result->fetch_assoc())
{ $email=$row["email"]; $shopname=$row["shopname"]; $contacts=$row["contacts"] ; $location=$row["location"]; 
}}
 

date_default_timezone_set('GMT');
$date = date("Y-m-d"); 
$today = date("Y/m/d"); 
$lseen = date("Y/m/d"); 
$year = date("Y");
$tid = date("m/Y"); 
 
$a = date('h');
$b = date('i:s');
$time = "$a : $b";
 
?>
<!DOCTYPE html>
<html>
<head>
<title><?php echo $shopname;?></title>
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
<!-- Custom Theme files -->
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<!-- Custom Theme files -->
<script src="js/jquery.min.js"></script>
<!-- Custom Theme files -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--webfont-->
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>

 <style>
      /* Popup Box */
      /* The Modal (background) */
      .modal {
      display: none; /* Hidden by default */
      position: fixed; /* Stay in place */
      z-index: 8888; /* Sit on top */
      left: 0;
      top: 0;
      width: 100%; /* Full width */
      height: 100%; /* Full height */
      overflow: auto; /* Enable scroll if needed */
      background-color: rgb(0,0,0); /* Fallback color */
      background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
      }
      /* Modal Content/Box */
      .modal-content {
      background-color: #fefefe;
      margin: 10vh auto; /* 15% from the top and centered */
      padding: 20px;
      border: 1px solid #888;
      width: 90%; /* Could be more or less, depending on screen size */
      }
      @media (min-width: 1366px) {
      .modal-content {
      background-color: #fefefe;
      margin: 10vh auto; /* 15% from the top and centered */
      padding: 20px;
      border: 1px solid #888;
      width: 90%; /* Could be more or less, depending on screen size */
      }
      }
       span{
      color: #666;
      display:block;
      padding:0 0 5px;
      }
      button:hover {
      background: #2371a0;
      }    
      /* The Close Button */
      .close {
      color: #aaa;
      float: right;
      font-size: 28px;
      font-weight: bold;
      }
      .close:hover,
      .close:focus {
      color: black;
      text-decoration: none;
      cursor: pointer;
      }
      button.button {
      background:none;
      border-top:none;
      outline: none;
      border-right:none;
      border-left:none;
      border-bottom:#02274a 1px solid;
      padding:0 0 3px 0;
      font-size:16px;
      cursor:pointer;
      }
      button.button:hover {
      border-bottom:#a99567 1px solid;
      color:#a99567;
      }
    </style>
</head>
<body>
	<!-- header-section-starts -->
	<div class="full">
			<div class="menu">
				<ul>
					<!--<li><a class="active" href="./"><i class="home"></i></a></li>-->
					<li><a href="#" class="button" data-modal="addproduct" title="Add Product"><div class="bk" style=" "> ADD PRODUCTS</div></a></li>
					
					 <li><a href="#" class="button" data-modal="selling" title="Selling"><div class="cat" style=" ">SELL</div></a></li>
					<li><a href="#" class="button" data-modal="reports" title="Reports"><div class="bk"  >REPORTS</div></a></li>
					
					<li> <a href="#" class="button" data-modal="stock" title="Stock"><div title="Stock" class="bk"  >STOCK</div></a></li>
					<li> <a href="#" class="button" data-modal="users" title="users"><div title="users" class="bk"  >USERS</div></a></li>
					<li> <a href="#" class="button" data-modal="addcustomers" title="add customers"><div title="add customers" class="bk"  >ADD CUSTOMERS</div></a></li>
					<li> <a href="#" class="button" data-modal="customers" title="Stock"><div title="customers" class="bk"  >CUSTOMERS</div></a></li>
					<li> <a href="#" class="button" data-modal="expenses" title="Expenses"><div title="expenses" class="bk"  >EXPENSES</div></a></li>
					
					
					<li> <a href="#" class="button" data-modal="trash" title="trash"><div title="Trash" class="bk"  >TRASH</div></a></li>
					
					</ul>
			</div>
		<div class="main">
		<div class="header">
			<div class="top-header">
				<div class="logo">
					<!--<a href="index.html"><img src="images/logo.png" alt="" /></a>-->
					<p><?php echo "$shopname $fullname";?></p>
				</div>
				<form action="login/" method="post" id="frmLogout">
   <div style="margin:10px;position:absolute;right:0px;top:0px"><input type="submit" id="submit" name="logout" value="logout" style=" padding:2px;background-color:brown;color:#fff;border-style:none" class="logout-button"> </div>  
</form>    
				<div class="clearfix"></div>
			</div>
			<div class="header-info">
				<h1><?php echo $shopname;?></h1>
				<p class="age"><a href="#">Location</a> <?php echo $location;?></p>
				<!--
				<p class="review">Rating	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp;  8,5/10</p>
				<p class="review reviewgo">Genre	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; : &nbsp;&nbsp; Animation, Action, Comedy</p>
				<p class="review">Release &nbsp;&nbsp;&nbsp;&nbsp;: &nbsp;&nbsp; 7 November 2014</p>
				-->
				<p class="special">Contacts: <?php echo $contacts;?></p> 
				<p class="special">Email: <?php echo $email;?></p>
				<!--<a class="video" href="#"><i class="video1"></i>WATCH TRAILER</a>
				<a class="book" href="#"><i class="book1"></i>BOOK TICKET</a>-->
			</div>
		</div>
		<!--
		<div class="review-slider">
			 <ul id="flexiselDemo1">
			<li><img src="images/r1.jpg" alt=""/></li>
			<li><img src="images/r2.jpg" alt=""/></li>
			<li><img src="images/r3.jpg" alt=""/></li>
			<li><img src="images/r4.jpg" alt=""/></li>
			<li><img src="images/r5.jpg" alt=""/></li>
			<li><img src="images/r6.jpg" alt=""/></li>
		</ul>
			<script type="text/javascript">
		$(window).load(function() {
			
		  $("#flexiselDemo1").flexisel({
				visibleItems: 6,
				animationSpeed: 1000,
				autoPlay: true,
				autoPlaySpeed: 3000,    		
				pauseOnHover: false,
				enableResponsiveBreakpoints: true,
				responsiveBreakpoints: { 
					portrait: { 
						changePoint:480,
						visibleItems: 2
					}, 
					landscape: { 
						changePoint:640,
						visibleItems: 3
					},
					tablet: { 
						changePoint:768,
						visibleItems: 4
					}
				}
			});
			});
		</script>
		<script type="text/javascript" src="js/jquery.flexisel.js"></script>	
		</div>
		<div class="video">
			<iframe  src="https://www.youtube.com/embed/2LqzF5WauAw" frameborder="0" allowfullscreen></iframe>
		</div>
		<div class="news">
			<div class="col-md-6 news-left-grid">
				<h3>Don’t be late,</h3>
				<h2>Book your ticket now!</h2>
				<h4>Easy, simple & fast.</h4>
				<a href="#"><i class="book"></i>BOOK TICKET</a>
				<p>Get Discount up to <strong>10%</strong> if you are a member!</p>
			</div>
			<div class="col-md-6 news-right-grid">
				<h3>News</h3>
				<div class="news-grid">
					<h5>Lorem Ipsum Dolor Sit Amet</h5>
					<label>Nov 11 2014</label>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
				</div>
				<div class="news-grid">
					<h5>Lorem Ipsum Dolor Sit Amet</h5>
					<label>Nov 11 2014</label>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo.</p>
				</div>
				<a class="more" href="#">MORE</a>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="more-reviews">
			 <ul id="flexiselDemo2">
			<li><img src="images/m1.jpg" alt=""/></li>
			<li><img src="images/m2.jpg" alt=""/></li>
			<li><img src="images/m3.jpg" alt=""/></li>
			<li><img src="images/m4.jpg" alt=""/></li>
		</ul>
			<script type="text/javascript">
		$(window).load(function() {
			
		  $("#flexiselDemo2").flexisel({
				visibleItems: 4,
				animationSpeed: 1000,
				autoPlay: true,
				autoPlaySpeed: 3000,    		
				pauseOnHover: false,
				enableResponsiveBreakpoints: true,
				responsiveBreakpoints: { 
					portrait: { 
						changePoint:480,
						visibleItems: 2
					}, 
					landscape: { 
						changePoint:640,
						visibleItems: 3
					},
					tablet: { 
						changePoint:768,
						visibleItems: 3
					}
				}
			});
			});
		</script>
		<script type="text/javascript" src="js/jquery.flexisel.js"></script>	
		</div>	
		-->
		
		
		 <div id="selling" class="modal">
      <div class="modal-content">
        <div class="contact-form">
          <a class="close">&times;</a>
          <form action="/">
            <h2>Selling</h2>
            <div>
             <iframe style="height:450px;width:100%" src="sellproduct111222555.php" frameborder="0" style="border:0"></iframe> 
	
            </div>
              </form>
        </div>
      </div>
    </div>
	
	
	 <div id="customers" class="modal">
      <div class="modal-content">
        <div class="contact-form">
          <a class="close">&times;</a>
          <form action="/">
            <h2>Customers</h2>
            <div>
             <iframe style="height:450px;width:100%" src="customers7304703.php" frameborder="0" style="border:0"></iframe> 
	
            </div>
              </form>
        </div>
      </div>
    </div>
	
	<div id="expenses" class="modal">
      <div class="modal-content">
        <div class="contact-form">
          <a class="close">&times;</a>
          <form action="/">
            <h2>Add Expenses</h2>
            <div>
             <iframe style="height:450px;width:100%" src="addexpenses75430703.php" frameborder="0" style="border:0"></iframe> 
	
            </div>
              </form>
        </div>
      </div>
    </div>
	
	 <div id="addcustomers" class="modal">
      <div class="modal-content">
        <div class="contact-form">
          <a class="close">&times;</a>
          <form action="/">
            <h2>Add Customers</h2>
            <div>
             <iframe style="height:450px;width:100%" src="addcustomer7598375.php" frameborder="0" style="border:0"></iframe> 
	
            </div>
              </form>
        </div>
      </div>
    </div>
	
	
	 <div id="stock" class="modal">
      <div class="modal-content">
        <div class="contact-form">
          <a class="close">&times;</a>
          <form action="/">
            <h2>Stock</h2>
            <div>
             <iframe style="height:450px;width:100%" src="stock111222555.php" frameborder="0" style="border:0"></iframe> 
	
            </div>
              </form>
        </div>
      </div>
    </div>
	
	<div id="trash" class="modal">
      <div class="modal-content">
        <div class="contact-form">
          <a class="close">&times;</a>
          <form action="/">
            <h2>Trash</h2>
            <div>
             <iframe style="height:450px;width:100%" src="trash111222555.php" frameborder="0" style="border:0"></iframe> 
	
            </div>
              </form>
        </div>
      </div>
    </div>
	
	
	<div id="users" class="modal">
      <div class="modal-content">
        <div class="contact-form">
          <a class="close">&times;</a>
          <form action="/">
            <h2>Users</h2>
            <div>
             <iframe style="height:450px;width:100%" src="adduser438325842782.php" frameborder="0" style="border:0"></iframe> 
	
            </div>
              </form>
        </div>
      </div>
    </div>
	
	
	 <div id="addproduct" class="modal">
      <div class="modal-content">
        <div class="contact-form">
          <a class="close">&times;</a>
          <form action="/">
            <h2>Add Product</h2>
            <div>
             <iframe style="height:450px;width:100%" src="addproduct111222555.php" frameborder="0" style="border:0"></iframe> 
	
            </div>
              </form>
        </div>
      </div>
    </div>
	
	 <div id="reports" class="modal">
      <div class="modal-content">
        <div class="contact-form">
          <a class="close">&times;</a>
          <form action="/">
            <h2>Reports</h2>
            <div>
             <iframe style="height:450px;width:100%" src="reports111222555.php" frameborder="0" style="border:0"></iframe> 
	
            </div>
              </form>
        </div>
      </div>
    </div>
	
	
	<div class="footer" align="right">
		<h6>Disclaimer : </h6>
		<p class="claim"><?php echo $shopname;?>. All right reserved.</p>
		 
	</div>	
	</div>
	</div>
	<div class="clearfix"></div>
	
	 <script>
      var modalBtns = [...document.querySelectorAll(".button")];
      modalBtns.forEach(function(btn){
        btn.onclick = function() {
          var modal = btn.getAttribute('data-modal');
          document.getElementById(modal).style.display = "block";
        }
      });
      
      var closeBtns = [...document.querySelectorAll(".close")];
      closeBtns.forEach(function(btn){
        btn.onclick = function() {
          var modal = btn.closest('.modal');
          modal.style.display = "none";
        }
      });
      
      window.onclick = function(event) {
        if (event.target.className === "modal") {
          event.target.style.display = "none";
        }
      }
    </script>
</body>
</html>